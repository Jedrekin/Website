import React from "react";

function Foods() {
  return (
    <div>
      <h1>My Favourite Foods</h1>
      <ul>
        <li>
          Bacon{" "}
          <img
            src="https://picsum.photos/seed/fsafdasfaaf4564sd5fdas/200"
            alt="náhodný obrázek"
          />
        </li>
        <li>
          Jamon{" "}
          <img
            src="https://picsum.photos/seed/adsf5as64af4csav56fs4a6/200"
            alt="náhodný obrázek"
          />
        </li>
        <li>
          Noodles{" "}
          <img
            src="https://picsum.photos/seed/asdfva45641f11abs6d7fva3sd53/200"
            alt="náhodný obrázek"
          />
        </li>
      </ul>
    </div>
  );
}

export default Foods;
