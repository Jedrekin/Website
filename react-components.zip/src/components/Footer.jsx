import React from "react";

function Footer() {
  return (
    <footer>
      <p>
        &copy; {new Date().getFullYear()}{" "}
        <a href="mailto:jan.zurek@student.gyarab.cz">Jan Žůrek</a>
      </p>
    </footer>
  );
}

export default Footer;
