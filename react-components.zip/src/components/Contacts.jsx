import React from "react";
import Card from "./Card";
import contacts from "../contacts";

function Contacts() {
  var conts = [];
  var i = 0;
  while (i != contacts.length) {
    conts.push(
      <Card
        name={contacts[i].name}
        img={contacts[i].img}
        email={contacts[i].email}
        tel={contacts[i].tel}
      />
    );
    i++;
  }
  return <div>{conts}</div>;
}

export default Contacts;
