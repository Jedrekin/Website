const contacts = [
  {
    id: 1,
    name: "Her Majesty The Queen",
    img: "https://picsum.photos/seed/qowjda0/200",
    email: "Elizabeth.II@royal.family.co.uk",
    tel: "+IDK Top secret"
  },
  {
    id: 1,
    name: "Elon Musk",
    img: "https://picsum.photos/seed/ff2233/200",
    email: "elon.musk@volny.cz",
    tel: "+420 777 123 456"
  },
  {
    id: 2,
    name: "Bill Gates",
    img: "https://picsum.photos/seed/ff2s3a/200",
    email: "bill.gates@atlas.cz",
    tel: "+420 602 123 000"
  },
  {
    id: 3,
    name: "Mark Zucker",
    img: "https://picsum.photos/seed/abcdefgh3/200",
    email: "marek@centrum.cz",
    tel: "+420 720 000 000"
  },
  {
    id: 4,
    name: "Adam Kourak",
    img: "https://picsum.photos/seed/ankugda/200",
    email: "adam.koural@student.gyarab.cz",
    tel: "+420 556 668 877 715 55"
  },
  {
    id: 5,
    name: "Eric Cartman",
    img: "https://picsum.photos/seed/666/200",
    email: "marek@centrum.cz",
    tel: "+420 666 666 666"
  }
];

export default contacts;
